export https_proxy=http://192.168.2.157:7890
export http_proxy=http://192.168.2.157:7890
