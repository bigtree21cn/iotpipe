CREATE CONTINUOUS QUERY "cq_productA_hourly" ON "iot"
BEGIN
  SELECT mean("params_co2"), mean("params_pm25"), mean("params_temperature") INTO "productA_hourly" FROM "productA" GROUP BY time(1h)
END
